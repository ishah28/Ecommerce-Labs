package restService;

import java.util.HashMap;


import com.google.gson.Gson;

public class Catalog {

		public static Catalog instance;
		
		//here the Hashmap is a placeholder for a database;
		//it is used for illustrative purposes to keep data...
		HashMap<String, Plant> catalog;
		
		public static Catalog getInstance()throws ClassNotFoundException{
			if (instance==null) {
				instance =new Catalog();
				
				//normally this class connects to a database and gets the data from there..
				//to keep it simple, we hard code a sample catalog 
				
				instance.catalog=new HashMap<String, Plant>();
				instance.catalog.put("rose", new Plant("rose", 10.9, "Most popular"));
				instance.catalog.put("tulip", new Plant("tulip", 5.0,  "Discounted"));
				instance.catalog.put("lily", new Plant("lily", 5.0,   "Available in Spring"));	
					
			}
				return instance;	
				
		}
		
		private Catalog() {
		}
		
		public void put (String id, String name, double price, String d) {
			instance.catalog.put(id, new Plant(name, price, d));

		}
		
		public String getPlant (String id) {
			Gson gson= new Gson();
			return gson.toJson(instance.catalog.get(id));
			
		}

		/* to be completed as exercise*/
		public void remove(String name) {
	    	//
			
		}
		
		/* to be completed as exercise*/
	    public void replace(String name, String price) {
	//
	}
		
		public String getCatalogAsJSON() {
			String result;
			Gson gson=new Gson();
			result=gson.toJson(catalog);
	        return result;
		}
	

	
}
