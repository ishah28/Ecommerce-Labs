package restService;

//import jakarta packages for web services
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

//this class is a simple implementation of a REST service
//it is the simplest Plant catalog

@Path("Plants") // this is the path of the service, http://localhost:8080/PlantStore/rest/Plants
public class PlantsForSale {

	Catalog catalog;

	public PlantsForSale() {

		try {
			// catalog is a singleton, shared among all customers
			catalog = Catalog.getInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/* GET Plants */
	// return the collection of plants as JSON

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPlantsNames() {
		String content = catalog.getCatalogAsJSON();
		return Response.status(200).entity(content).build();

	}

	/* GET Plants/{id} */
	// this is a READ method on the service
	// the resource name is plants, is a collection,
	// once you deploy this, you can access this method with
	// the url is http://localhost:8080/SampleStore/rest/Plants

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPrice(@DefaultValue("rose") @PathParam("id") String id) {
		String content = catalog.getPlant(id);
		return Response.status(200).entity(content).build();
	}

	/* POST plants */
	// this is a CREATE method on the service
	// the resource name is plant, the operation is POST, the parameters are passed
	// as parameters in a form/query/path
	// once you deploy this, you can access this method with
	// http://localhost:8080/SampleStore/rest/Plants?id={id}...
	// you can invoke it at the above address but need to include the parameters


	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	public Response createPlant(@QueryParam("id") String id, @QueryParam("plantName") String name, @QueryParam("price") double price, @QueryParam("desc") String desc) {
		System.out.println("received:" + name + " " + price);
		catalog.put(id, name, price, desc);
		String content = catalog.getCatalogAsJSON();
		return Response.status(200).entity(content).build();
	}
	

	/* to be completed */
	public void deletePlant(String name) {
		catalog.remove(name);

	}

	/* to be completed */
	public void updatePlant(String name, String price) {
		catalog.replace(name, price);
	}

}
